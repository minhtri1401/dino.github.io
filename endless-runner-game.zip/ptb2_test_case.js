//Chuẩn bị 20 trường hợp 
var lstCase = [
    {eqaParams: [1,2,1], results: [-1]},
    {eqaParams: [0,2,1], results: [-0.5]},
    {eqaParams: [1,0,1], results: []},
    {eqaParams: [7,-2,3], results: []},
    {eqaParams: [2,-7,3], results: [0.5,3]},
    {eqaParams: [6,1,-5], results: [-1,5/6]},
    {eqaParams: [1,-8,16], results: [4]},
    {eqaParams: [16,24,9], results: [-0.75]},
    {eqaParams: [3,5,2], results: [-1,-2/3]},
    {eqaParams: [6,1,-5], results: []},
    {eqaParams: [4,-4,1], results: [1/2]},
    {eqaParams: [25,0,-16], results: [-4/5,4/5]},
    
];


